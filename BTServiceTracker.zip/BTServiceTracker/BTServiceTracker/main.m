//
//  main.m
//  BTServiceTracker
//
//  Created by Lakhpat on 08/04/16.
//  Copyright (c) 2016 Accolite. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BTAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BTAppDelegate class]));
    }
}
