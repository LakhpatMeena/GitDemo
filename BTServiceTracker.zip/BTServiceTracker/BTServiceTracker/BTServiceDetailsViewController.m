//
//  BTServiceDetailsViewController.m
//  BTServiceTracker
//
//  Created by Lakhpat on 13/04/16.
//  Copyright (c) 2016 Accolite. All rights reserved.
//

#import "BTServiceDetailsViewController.h"
#import "BTServiceDetailsTableViewCell.h"

@interface BTServiceDetailsViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UIView *headerView;
@property (weak, nonatomic) IBOutlet UITableView *serviceIdDetailsTableView;
@property (weak, nonatomic) IBOutlet UILabel *serviceIdInfoLabel;



@end

@implementation BTServiceDetailsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //table data view
    self.serviceIdDetailsTableView.delegate = self;
    self.serviceIdDetailsTableView.dataSource = self;
    self.serviceIdDetailsTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.serviceIdDetailsTableView.backgroundColor = [UIColor clearColor];
    
    UINib *nib = [UINib nibWithNibName:@"BTServiceDetailsTableViewCell" bundle:nil];
    
    [self.serviceIdDetailsTableView registerNib:nib forCellReuseIdentifier:@"BTServiceDetailsTableViewCell"];
    
    self.serviceIdInfoLabel.font = [UIFont fontWithName:@"BTFont-ExtraBold" size:20];
    self.serviceIdInfoLabel.textColor = [UIColor colorWithWhite:225 alpha:1.0];
    self.serviceIdInfoLabel.text = self.serviceIdString;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor lightTextColor],NSFontAttributeName:[UIFont fontWithName:@"NewBT-Regular" size:19]}];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    BTServiceDetailsTableViewCell *faultDetailCell = [tableView dequeueReusableCellWithIdentifier:@"BTServiceDetailsTableViewCell" forIndexPath:indexPath];
    
    
    return faultDetailCell;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
