//
//  BTServiceDetailsViewController.h
//  BTServiceTracker
//
//  Created by Lakhpat on 13/04/16.
//  Copyright (c) 2016 Accolite. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BTServiceDetailsViewController : UIViewController

@property (nonatomic, strong) NSString * serviceIdString;

@end
