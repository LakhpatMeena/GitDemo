//
//  BTFaultData.m
//  BTServiceTracker
//
//  Created by Lakhpat on 19/04/16.
//  Copyright (c) 2016 Accolite. All rights reserved.
//

#import "BTFaultData.h"

@implementation BTFaultData

@synthesize statusOnUI;
@synthesize faultReference;
@synthesize reportedOn;
@synthesize productGroup;
@synthesize productImage;

@end
